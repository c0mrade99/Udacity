#include "ros/ros.h"
#include "geometry_msgs/Twist.h"
#include "ball_chaser/DriveToTarget.h"

ros::Publisher MotorCommandPublisher;


bool hRequest(ball_chaser::DriveToTarget::Request& rq, ball_chaser::DriveToTarget::Response& rs)
{


  geometry_msgs::Twist MotorCommand;

  MotorCommand.linear.x = rq.linear_x; 
  MotorCommand.angular.z = rq.angular_z; 
  
  MotorCommandPublisher.publish(MotorCommand);


  rs.msg_feedback = "Move command  : linear_x = " + std::to_string(MotorCommand.linear.x) + ", angular_z = " + std::to_string(MotorCommand.angular.z);

  ROS_INFO_STREAM(rs.msg_feedback);
  

  return true;

}


int main(int argc, char** argv)
{

    ros::init(argc, argv, "drive_bot");

    ros::NodeHandle nHandle;

    MotorCommandPublisher = nHandle.advertise<geometry_msgs::Twist>("/cmd_vel", 10);

    ros::ServiceServer service = nHandle.advertiseService("/ball_chaser/command_robot", hRequest);
    ROS_INFO("Ready for command...");

    ros::spin();

    return 0;
}